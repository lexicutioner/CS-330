#pragma once

#define DICE_VERTEXNUM			12
extern GLfloat diceverts[];

#define PLANETABLE_VERTEXNUM			36
extern GLfloat PlaneTableverts[];

#define CAMERAMESH_VERTEXNUM			36
extern GLfloat CameraMeshverts[];

#define cylinder_VERTEXNUM			36
extern GLfloat cylinderverts[];

#define cylinder2_VERTEXNUM			36
extern GLfloat cylinderverts2[];

#define cylinder3_VERTEXNUM			36
extern GLfloat cylinderverts3[];

#define cylinder4_VERTEXNUM			36
extern GLfloat cylinderverts4[];

#define cylinderface_VERTEXNUM			36
extern GLfloat cylinderfaceverts[];

#define cylinderface2_VERTEXNUM			24
extern GLfloat cylinderfaceverts2[];

#define MAKEUP_VERTEXNUM			36
extern GLfloat makeupverts[];

#define alexa_VERTEXNUM			36
extern GLfloat alexaverts[];

#define alexa2_VERTEXNUM			36
extern GLfloat alexaverts2[];

#define alexa3_VERTEXNUM			36
extern GLfloat alexaverts3[];

#define alexa4_VERTEXNUM			24
extern GLfloat alexaverts4[];

#define alexatop_VERTEXNUM			36
extern GLfloat alexatopverts[];

#define alexatop2_VERTEXNUM			24
extern GLfloat alexatopverts2[];
