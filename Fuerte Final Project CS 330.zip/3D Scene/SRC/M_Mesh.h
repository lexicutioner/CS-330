#pragma once



#define	M_MESH_MAXTEXTURELAYERS			4				// If you update this value you must update various functions in this module

// Rapresent a single mesh(a 3d object)
// Note that its better to create a class for future implementations
struct M_MESH
{
	GLuint vao;											// Handle for the vertex array object
	GLuint vbos[1];										// Handles for the vertex buffer objects
	GLfloat WorldPosition[3];							// Actual World Position of the object X,Y,Z

	GLuint nVertices;

	GLuint TexturesID[M_MESH_MAXTEXTURELAYERS];			// Array of texturesID wich are the layers currently active
	GLint  BindedTexturesNum;							// Num of currently active texture layers (minimum 1)

	GLuint RenderMode;									// Specify the render mode for this object. 0=SOLID(default); 1=WIREFRAME

	// Matrix object transformations
	// It would be the same to have here the properties instead of directly the matrices
	glm::mat4 scale;
	glm::mat4 rotation;
	glm::mat4 translation;
};


void M_InitMesh(M_MESH* aMesh,GLfloat* aVertices,int aNumVertex);

void M_DestroyMesh(M_MESH* aMesh);

void M_MeshAddTextureLayer(M_MESH* aMesh,GLuint aTextureID);

void M_RenderMesh(M_MESH* aMesh,GLuint aShaderProgramId);

void M_SetMeshScale(M_MESH* aMesh, GLfloat aX, GLfloat aY, GLfloat aZ);

void M_SetMeshRotation(M_MESH* aMesh, GLfloat aAngleDegree, GLfloat aX, GLfloat aY, GLfloat aZ);

void M_SetMeshWorldPosition(M_MESH* aMesh, GLfloat aX, GLfloat aY, GLfloat aZ);

bool M_LoadTexture(const char* aFilePathName,GLuint& NewTextureID);
void M_DestroyTexture(GLuint aTextureID);

void M_flipImageVertically(unsigned char *image, int width, int height, int channels);

