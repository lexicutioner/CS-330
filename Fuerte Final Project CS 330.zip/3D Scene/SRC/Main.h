
#pragma once


#define G_LIGHTSNUM			4						// !!!IMPORTANT: This value MUST be identical to the const LIGHTSNUM inside the shader!

struct M_LIGHT
{
	glm::vec3 Position;
	glm::vec3 Color;
	float SpecularIntensity;
	float SpecularHighlightSize;
};



bool UInitialize(int, char* [], GLFWwindow** window);

void UResizeWindow(GLFWwindow* window, int width, int height);

bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId);
void UDestroyShaderProgram(GLuint programId);

void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos);
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset);
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods);





